$(document).ready(function() {
   $(".b").mouseenter(function() {
       $(this).animate({
           height: "+=10px",
           width: "+=10px"

       });
   });
   $(".b").mouseleave(function() {
       $(this).animate({
           height: '-=10px',
           width: '-=10px'
       }); 
   });

   $("#flip").click(function(){
        $("#panel").slideDown(5000);
    });
    $("#stop").click(function(){
        $("#panel").stop();
    });

    function myFunction() { 
    document.getElementById("mp4_src").src = "movie.mp4";
  
    document.getElementById("myVideo").load();
} 


});

  